﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Mahasiswa
{
    public string Nim {  get; set; }
    public string Nama { get; set; }
    public string Alamat {  get; set; }
    public DateOnly Tanggal_lahir { get; set; }
}